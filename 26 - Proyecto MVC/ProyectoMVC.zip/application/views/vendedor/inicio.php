<!DOCTYPE html>
<html>
	<head>
		<title>VENDEDOR</title>
	</head>
	<body>
		<h1>INICIO DEL VENDEDOR</h1>
		<?php 
			print_r( $session );
		?>
	</body>
</html>